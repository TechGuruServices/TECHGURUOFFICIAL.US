/*
 * Premium TECHGURU Landing Page JavaScript
 *
 * Handles form submissions, rotating taglines, hamburger menu, FAQ accordion,
 * exit intent popup, and smooth interactions.
 */

document.addEventListener('DOMContentLoaded', () => {
  // ============================================
  // ROTATING TAGLINES
  // ============================================
  const taglines = [
    "Streamline. Automate. Elevate.",
    "Premium Automation & AI Systems.",
    "Tech‑driven solutions built fast.",
    "Where Automation Meets Elegance.",
    "Modern Systems. Premium Design.",
    "Faster Than Agencies. More Modern Than MSPs.",
    "Automation‑First. AI‑Enhanced.",
    "Apple‑Grade Clarity. LV‑Level Polish.",
    "Lightweight. Reliable. Scalable.",
    "Transform Complexity Into Beautiful Simplicity."
  ];

  const taglineEl = document.getElementById('rotating-tagline');
  if (taglineEl) {
    let currentIndex = 0;

    const rotateTagline = () => {
      taglineEl.classList.add('fade');

      setTimeout(() => {
        currentIndex = (currentIndex + 1) % taglines.length;
        taglineEl.textContent = taglines[currentIndex];
        taglineEl.classList.remove('fade');
      }, 500);
    };

    setInterval(rotateTagline, 4000);
  }

  // ============================================
  // HAMBURGER MENU
  // ============================================
  const navToggle = document.getElementById('nav-toggle');
  const navMenu = document.getElementById('nav-menu');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      navToggle.classList.toggle('active');
      navMenu.classList.toggle('active');
    });

    // Close menu when clicking a link
    navMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navToggle.classList.remove('active');
        navMenu.classList.remove('active');
      });
    });

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
      if (!navToggle.contains(e.target) && !navMenu.contains(e.target)) {
        navToggle.classList.remove('active');
        navMenu.classList.remove('active');
      }
    });
  }

  // ============================================
  // FAQ ACCORDION
  // ============================================
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');

    question.addEventListener('click', () => {
      const isActive = item.classList.contains('active');

      // Close all other items
      faqItems.forEach(otherItem => {
        otherItem.classList.remove('active');
        otherItem.querySelector('.faq-question').setAttribute('aria-expanded', 'false');
      });

      // Toggle current item
      if (!isActive) {
        item.classList.add('active');
        question.setAttribute('aria-expanded', 'true');
      }
    });
  });

  // ============================================
  // PRICING DROPDOWN TOGGLES
  // ============================================
  const pricingToggles = document.querySelectorAll('.pricing-toggle');

  pricingToggles.forEach(toggle => {
    toggle.addEventListener('click', () => {
      const card = toggle.closest('.service-card-premium');
      const dropdown = card.querySelector('.pricing-dropdown');
      const isExpanded = toggle.getAttribute('aria-expanded') === 'true';

      // Toggle state
      toggle.setAttribute('aria-expanded', !isExpanded);
      card.classList.toggle('pricing-open');

      // Animate dropdown
      if (!isExpanded) {
        dropdown.style.maxHeight = dropdown.scrollHeight + 'px';
        dropdown.style.opacity = '1';
      } else {
        dropdown.style.maxHeight = '0';
        dropdown.style.opacity = '0';
      }
    });
  });

  // ============================================
  // EXIT INTENT POPUP
  // ============================================
  const exitPopup = document.getElementById('exit-popup');
  const exitPopupClose = document.getElementById('exit-popup-close');
  const exitPopupForm = document.getElementById('exit-popup-form');
  let hasShownExitPopup = sessionStorage.getItem('exitPopupShown');

  if (exitPopup && !hasShownExitPopup) {
    // Desktop: Mouse leaves viewport from top
    document.addEventListener('mouseout', (e) => {
      if (e.clientY < 10 && !hasShownExitPopup) {
        showExitPopup();
      }
    });

    // Mobile: Show after significant scroll up (returning to top)
    let lastScrollY = window.scrollY;
    let scrollUpDistance = 0;

    window.addEventListener('scroll', () => {
      const currentScrollY = window.scrollY;

      if (currentScrollY < lastScrollY) {
        scrollUpDistance += lastScrollY - currentScrollY;

        if (scrollUpDistance > 300 && currentScrollY < 200 && !hasShownExitPopup) {
          showExitPopup();
        }
      } else {
        scrollUpDistance = 0;
      }

      lastScrollY = currentScrollY;
    });
  }

  function showExitPopup() {
    if (exitPopup && !hasShownExitPopup) {
      exitPopup.classList.add('active');
      hasShownExitPopup = true;
      sessionStorage.setItem('exitPopupShown', 'true');
    }
  }

  if (exitPopupClose) {
    exitPopupClose.addEventListener('click', () => {
      exitPopup.classList.remove('active');
    });
  }

  if (exitPopup) {
    exitPopup.addEventListener('click', (e) => {
      if (e.target === exitPopup) {
        exitPopup.classList.remove('active');
      }
    });
  }

  if (exitPopupForm) {
    exitPopupForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const emailInput = exitPopupForm.querySelector('input[type="email"]');
      const email = emailInput.value.trim();

      if (!email) return;

      try {
        const res = await fetch('/api/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, source: 'exit-popup' })
        });

        if (res.ok) {
          exitPopupForm.innerHTML = '<p style="color: var(--color-accent);">✓ You\'re in! Check your inbox.</p>';
          setTimeout(() => exitPopup.classList.remove('active'), 2000);
        } else {
          throw new Error('Subscription failed');
        }
      } catch (err) {
        console.error(err);
        exitPopupForm.innerHTML = '<p style="color: #ff6b6b;">Something went wrong. Try again later.</p>';
      }
    });
  }

  // ============================================
  // NEWSLETTER SUBSCRIPTION
  // ============================================
  const subscribeForm = document.getElementById('subscribe-form');
  if (subscribeForm) {
    subscribeForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const emailInput = document.getElementById('subscribe-email');
      const email = emailInput.value.trim();
      const button = subscribeForm.querySelector('button');
      const originalText = button.textContent;

      if (!email) {
        showFormMessage(subscribeForm, 'Please enter a valid email address.', 'error');
        return;
      }

      button.textContent = 'Sending...';
      button.disabled = true;

      try {
        const res = await fetch('/api/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email })
        });
        if (!res.ok) throw new Error('Network response was not ok');

        showFormMessage(subscribeForm, '✓ Success! Check your inbox for the starter kit.', 'success');
        subscribeForm.reset();
      } catch (err) {
        console.error(err);
        showFormMessage(subscribeForm, 'Something went wrong. Please try again.', 'error');
      } finally {
        button.textContent = originalText;
        button.disabled = false;
      }
    });
  }

  // ============================================
  // CONTACT FORM
  // ============================================
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(contactForm);
      const payload = Object.fromEntries(formData.entries());
      const button = contactForm.querySelector('button');
      const originalText = button.textContent;

      button.textContent = 'Sending...';
      button.disabled = true;

      try {
        const res = await fetch('/api/contact', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        if (!res.ok) throw new Error('Network response was not ok');

        showFormMessage(contactForm, '✓ Message sent! We\'ll respond within 24 hours.', 'success');
        contactForm.reset();
      } catch (err) {
        console.error(err);
        showFormMessage(contactForm, 'Something went wrong. Please try again or contact us directly.', 'error');
      } finally {
        button.textContent = originalText;
        button.disabled = false;
      }
    });
  }

  // ============================================
  // FORM MESSAGE HELPER
  // ============================================
  function showFormMessage(form, message, type) {
    // Remove existing message
    const existingMsg = form.parentElement.querySelector('.form-message');
    if (existingMsg) existingMsg.remove();

    const msgEl = document.createElement('p');
    msgEl.className = 'form-message';
    msgEl.style.cssText = `
      margin-top: 1rem;
      padding: 0.8rem 1rem;
      border-radius: 8px;
      text-align: center;
      ${type === 'success'
        ? 'background: rgba(100, 222, 223, 0.1); color: #64dedf; border: 1px solid rgba(100, 222, 223, 0.3);'
        : 'background: rgba(255, 107, 107, 0.1); color: #ff6b6b; border: 1px solid rgba(255, 107, 107, 0.3);'
      }
    `;
    msgEl.textContent = message;
    form.parentElement.insertBefore(msgEl, form.nextSibling);

    // Auto-remove after 5 seconds
    setTimeout(() => msgEl.remove(), 5000);
  }

  // ============================================
  // NAVBAR HIDE/SHOW ON SCROLL
  // ============================================
  const navbar = document.querySelector('.navbar');
  let lastScrollY = window.scrollY;
  let ticking = false;

  const handleScroll = () => {
    const currentScrollY = window.scrollY;

    if (currentScrollY > lastScrollY && currentScrollY > 80) {
      navbar.classList.add('navbar-hidden');
    } else {
      navbar.classList.remove('navbar-hidden');
    }

    lastScrollY = currentScrollY;
    ticking = false;
  };

  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(handleScroll);
      ticking = true;
    }
  });

  // ============================================
  // SMOOTH SCROLL FOR ANCHOR LINKS
  // ============================================
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });
});
