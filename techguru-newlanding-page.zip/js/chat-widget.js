/*
 * Chat Widget JavaScript
 *
 * Handles chat widget toggle, message sending, and API integration
 * Connects to the TechGuru Workers API (/api/chat endpoint)
 * Includes proactive chat prompts for engagement
 */

document.addEventListener('DOMContentLoaded', () => {
  const chatToggle = document.getElementById('chat-toggle');
  const chatWindow = document.getElementById('chat-window');
  const chatClose = document.getElementById('chat-close');
  const chatForm = document.getElementById('chat-form');
  const chatInput = document.getElementById('chat-input');
  const chatMessages = document.getElementById('chat-messages');
  const chatHeader = document.querySelector('.chat-header');
  const chatContainer = document.querySelector('.chat-widget-container');
  const chatFloatingCtas = document.getElementById('chat-floating-ctas');

  const API_ENDPOINT = '/api/chat';
  let isOpen = false;
  let isLoading = false;
  let hasShownProactivePrompt = sessionStorage.getItem('chatPromptShown');
  let ctasVisible = false;
  let ctaHideTimeout = null;
  let messageCount = 0; // Track conversation length for lead capture
  let hasOfferedLeadCapture = false;

  // Dragging state
  let isDragging = false;
  let dragOffsetX = 0;
  let dragOffsetY = 0;
  let dragStartX = 0;
  let dragStartY = 0;
  let hasMoved = false;

  // Resizing state
  let isResizing = false;
  let resizeDirection = null;
  let resizeStartX = 0;
  let resizeStartY = 0;
  let resizeStartWidth = 0;
  let resizeStartHeight = 0;
  let resizeStartLeft = 0;
  let resizeStartTop = 0;
  let resizeStartRight = 0;
  let resizeStartBottom = 0;

  // Min and max dimensions
  const MIN_WIDTH = 280;
  const MIN_HEIGHT = 400;
  const MAX_WIDTH = 600;

  // Calculate max height dynamically to prevent overflow (viewport height - avatar height - padding)
  const getMaxHeight = () => Math.min(800, window.innerHeight - 140);

  // ============================================
  // FLOATING CTAs TOGGLE (show on hover/interaction)
  // ============================================
  function showFloatingCtas() {
    if (chatFloatingCtas && !isOpen) {
      chatFloatingCtas.classList.add('visible');
      ctasVisible = true;
      // Clear any existing hide timeout
      if (ctaHideTimeout) {
        clearTimeout(ctaHideTimeout);
        ctaHideTimeout = null;
      }
    }
  }

  function hideFloatingCtas() {
    if (chatFloatingCtas) {
      ctaHideTimeout = setTimeout(() => {
        chatFloatingCtas.classList.remove('visible');
        ctasVisible = false;
      }, 300);
    }
  }

  // Show CTAs on hover over chat widget container
  if (chatContainer && chatFloatingCtas) {
    chatContainer.addEventListener('mouseenter', showFloatingCtas);
    chatContainer.addEventListener('mouseleave', hideFloatingCtas);

    // Keep CTAs visible when hovering over them
    chatFloatingCtas.addEventListener('mouseenter', () => {
      if (ctaHideTimeout) {
        clearTimeout(ctaHideTimeout);
        ctaHideTimeout = null;
      }
    });
    chatFloatingCtas.addEventListener('mouseleave', hideFloatingCtas);

    // Show on touch for mobile
    chatToggle.addEventListener('touchstart', () => {
      if (!ctasVisible && !isOpen) {
        showFloatingCtas();
        // Auto-hide after 3 seconds on mobile
        setTimeout(() => {
          if (!isOpen) hideFloatingCtas();
        }, 3000);
      }
    }, { passive: true });
  }

  // ============================================
  // PROACTIVE CHAT PROMPT (30 seconds)
  // ============================================
  if (!hasShownProactivePrompt) {
    setTimeout(() => {
      if (!isOpen && !hasShownProactivePrompt) {
        showProactivePrompt();
      }
    }, 30000); // 30 seconds
  }

  function showProactivePrompt() {
    // Create notification bubble
    const promptBubble = document.createElement('div');
    promptBubble.className = 'chat-proactive-prompt';
    promptBubble.innerHTML = `
      <button class="prompt-close" aria-label="Close">&times;</button>
      <p>👋 Have questions about automation?</p>
      <span>Let's chat—I'm here to help.</span>
    `;

    // Style the bubble
    promptBubble.style.cssText = `
      position: absolute;
      bottom: 80px;
      right: 0;
      background: linear-gradient(135deg, rgba(74, 108, 247, 0.95), rgba(162, 116, 255, 0.95));
      color: white;
      padding: 1rem 1.25rem;
      border-radius: 12px 12px 0 12px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
      max-width: 220px;
      animation: promptSlideIn 0.4s ease;
      cursor: pointer;
      z-index: 1000;
    `;

    // Add animation keyframes
    if (!document.getElementById('proactive-prompt-styles')) {
      const styleSheet = document.createElement('style');
      styleSheet.id = 'proactive-prompt-styles';
      styleSheet.textContent = `
        @keyframes promptSlideIn {
          from {
            opacity: 0;
            transform: translateY(20px) scale(0.9);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
        .chat-proactive-prompt p {
          margin: 0 0 0.25rem 0;
          font-weight: 600;
          font-size: 0.95rem;
        }
        .chat-proactive-prompt span {
          font-size: 0.85rem;
          opacity: 0.9;
        }
        .chat-proactive-prompt .prompt-close {
          position: absolute;
          top: 0.25rem;
          right: 0.5rem;
          background: none;
          border: none;
          color: rgba(255,255,255,0.7);
          font-size: 1.2rem;
          cursor: pointer;
          padding: 0;
          line-height: 1;
        }
        .chat-proactive-prompt .prompt-close:hover {
          color: white;
        }
      `;
      document.head.appendChild(styleSheet);
    }

    chatContainer.appendChild(promptBubble);

    // Mark as shown
    hasShownProactivePrompt = true;
    sessionStorage.setItem('chatPromptShown', 'true');

    // Click to open chat
    promptBubble.addEventListener('click', (e) => {
      if (!e.target.classList.contains('prompt-close')) {
        promptBubble.remove();
        if (!isOpen) toggleChat();
      }
    });

    // Close button
    const closeBtn = promptBubble.querySelector('.prompt-close');
    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      promptBubble.remove();
    });

    // Auto-dismiss after 15 seconds
    setTimeout(() => {
      if (promptBubble.parentElement) {
        promptBubble.style.animation = 'promptSlideIn 0.3s ease reverse';
        setTimeout(() => promptBubble.remove(), 300);
      }
    }, 15000);
  }

  /**
   * Toggle chat window open/close
   */
  const toggleChat = (e) => {
    // Don't toggle if user was dragging
    if (hasMoved) {
      hasMoved = false;
      return;
    }

    isOpen = !isOpen;

    if (isOpen) {
      chatWindow.classList.add('open');
      chatToggle.classList.add('active');
      chatInput.focus();

      // Hide floating CTAs when chat opens
      if (chatFloatingCtas) {
        chatFloatingCtas.classList.remove('visible');
        ctasVisible = false;
      }

      // Show welcome message on first open
      if (chatMessages.children.length === 0) {
        addWelcomeMessage();
      }
    } else {
      chatWindow.classList.remove('open');
      chatToggle.classList.remove('active');
    }
  };

  /**
   * Drag functionality for chat widget container
   */
  const startDrag = (e) => {
    if (e.target.closest('.chat-close') || e.target.closest('#chat-input') || e.target.closest('.chat-send') || e.target.classList.contains('resize-handle')) {
      return; // Don't drag when clicking close button, input, or resize handles
    }

    isDragging = true;
    hasMoved = false;
    dragStartX = e.clientX;
    dragStartY = e.clientY;

    const rect = chatContainer.getBoundingClientRect();
    dragOffsetX = e.clientX - rect.left;
    dragOffsetY = e.clientY - rect.top;

    if (chatHeader.style) chatHeader.style.cursor = 'grabbing';
    e.preventDefault();
  };

  const drag = (e) => {
    if (!isDragging) return;

    const moveDistance = Math.abs(e.clientX - dragStartX) + Math.abs(e.clientY - dragStartY);
    if (moveDistance > 5) {
      hasMoved = true;
    }

    e.preventDefault();

    const newLeft = e.clientX - dragOffsetX;
    const newTop = e.clientY - dragOffsetY;

    // Update container position
    chatContainer.style.position = 'fixed';
    chatContainer.style.left = `${newLeft}px`;
    chatContainer.style.top = `${newTop}px`;
    chatContainer.style.right = 'auto';
    chatContainer.style.bottom = 'auto';
  };

  const stopDrag = (e) => {
    if (isDragging) {
      isDragging = false;
      if (chatHeader.style) chatHeader.style.cursor = 'move';
    }
  };

  /**
   * Resize functionality for chat window
   */
  const startResize = (e, direction) => {
    isResizing = true;
    resizeDirection = direction;
    resizeStartX = e.clientX;
    resizeStartY = e.clientY;

    const rect = chatWindow.getBoundingClientRect();
    const currentStyle = window.getComputedStyle(chatWindow);
    const containerStyle = window.getComputedStyle(chatContainer);

    resizeStartWidth = rect.width;
    resizeStartHeight = rect.height;

    // Check if using fixed positioning (after drag) or absolute (initial)
    const usingFixedPosition = containerStyle.position === 'fixed' && containerStyle.left !== 'auto';

    if (usingFixedPosition) {
      // Container has been dragged and uses left/top positioning
      resizeStartLeft = parseInt(containerStyle.left) || 0;
      resizeStartTop = parseInt(containerStyle.top) || 0;
    } else {
      // Using initial bottom/right positioning
      resizeStartRight = parseInt(currentStyle.right) || 0;
      resizeStartBottom = parseInt(currentStyle.bottom) || 120;
    }

    e.preventDefault();
    e.stopPropagation();
  };

  const resize = (e) => {
    if (!isResizing) return;

    e.preventDefault();

    const deltaX = e.clientX - resizeStartX;
    const deltaY = e.clientY - resizeStartY;

    let newWidth = resizeStartWidth;
    let newHeight = resizeStartHeight;

    const containerStyle = window.getComputedStyle(chatContainer);
    const usingFixedPosition = containerStyle.position === 'fixed' && containerStyle.left !== 'auto';

    // Calculate dynamic max height based on current position
    let maxAllowedHeight = getMaxHeight();

    if (usingFixedPosition) {
      // If using fixed positioning, calculate max height based on current top position
      const currentTop = parseInt(containerStyle.top) || 0;
      maxAllowedHeight = Math.min(maxAllowedHeight, window.innerHeight - currentTop - 20); // 20px bottom padding
    }

    // Handle horizontal resizing
    if (resizeDirection.includes('e')) {
      newWidth = resizeStartWidth + deltaX;
    } else if (resizeDirection.includes('w')) {
      newWidth = resizeStartWidth - deltaX;

      // Adjust position when resizing from west edge
      if (usingFixedPosition) {
        const widthDiff = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, newWidth)) - resizeStartWidth;
        const newLeft = resizeStartLeft - widthDiff;
        // Prevent moving off left edge
        chatContainer.style.left = `${Math.max(0, newLeft)}px`;
      } else {
        const widthDiff = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, newWidth)) - resizeStartWidth;
        chatWindow.style.right = `${resizeStartRight - widthDiff}px`;
      }
    }

    // Handle vertical resizing
    if (resizeDirection.includes('s')) {
      newHeight = resizeStartHeight + deltaY;
    } else if (resizeDirection.includes('n')) {
      newHeight = resizeStartHeight - deltaY;

      // Adjust position when resizing from north edge
      if (usingFixedPosition) {
        const heightDiff = Math.max(MIN_HEIGHT, Math.min(maxAllowedHeight, newHeight)) - resizeStartHeight;
        const newTop = resizeStartTop - heightDiff;
        // Prevent moving off top edge
        chatContainer.style.top = `${Math.max(0, newTop)}px`;
      } else {
        const heightDiff = Math.max(MIN_HEIGHT, Math.min(maxAllowedHeight, newHeight)) - resizeStartHeight;
        chatWindow.style.bottom = `${resizeStartBottom - heightDiff}px`;
      }
    }

    // Constrain to min/max dimensions (with dynamic viewport constraint for height)
    const constrainedWidth = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, newWidth));
    const constrainedHeight = Math.max(MIN_HEIGHT, Math.min(maxAllowedHeight, newHeight));

    chatWindow.style.width = `${constrainedWidth}px`;
    chatWindow.style.height = `${constrainedHeight}px`;
  };  const stopResize = () => {
    if (isResizing) {
      isResizing = false;
      resizeDirection = null;
    }
  };  /**
   * Add welcome message
   */
  const addWelcomeMessage = () => {
    addMessage(
      'Hello! Welcome to TECHGURU. I\'m here to help you discover how automation and AI can streamline your operations and enhance your digital presence. How can I assist you today?',
      'assistant'
    );
  };

  /**
   * Show lead capture prompt after multiple exchanges
   */
  const showLeadCapturePrompt = () => {
    if (hasOfferedLeadCapture) return;
    hasOfferedLeadCapture = true;

    const leadCaptureDiv = document.createElement('div');
    leadCaptureDiv.className = 'chat-lead-capture';
    leadCaptureDiv.innerHTML = `
      <p>Would you like to continue this conversation?</p>
      <a href="https://cal.com/techguru/strategy-call" target="_blank" rel="noopener" class="lead-cta-btn primary">
        Schedule Free Strategy Call
      </a>
      <button class="lead-cta-btn secondary" id="lead-email-btn">
        Get Resources via Email
      </button>
    `;
    chatMessages.appendChild(leadCaptureDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    // Handle email button click
    const emailBtn = document.getElementById('lead-email-btn');
    if (emailBtn) {
      emailBtn.addEventListener('click', () => {
        showEmailCapture(leadCaptureDiv);
      });
    }
  };

  /**
   * Show email input form
   */
  const showEmailCapture = (parentDiv) => {
    parentDiv.innerHTML = `
      <form id="chat-email-form" class="chat-email-form">
        <label for="chat-email-input">Enter your email for resources:</label>
        <div class="email-input-row">
          <input type="email" id="chat-email-input" placeholder="your@email.com" required>
          <button type="submit">Send</button>
        </div>
      </form>
    `;

    const emailForm = document.getElementById('chat-email-form');
    emailForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const emailInput = document.getElementById('chat-email-input');
      const email = emailInput.value.trim();

      if (!email) return;

      try {
        const res = await fetch('/api/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, source: 'chat-widget' })
        });

        if (res.ok) {
          parentDiv.innerHTML = `<p class="lead-success">Thanks! Check your inbox for the AI Automation Starter Kit.</p>`;
        } else {
          parentDiv.innerHTML = `<p class="lead-error">Something went wrong. Please try again.</p>`;
        }
      } catch (err) {
        parentDiv.innerHTML = `<p class="lead-error">Connection error. Please try again.</p>`;
      }
    });
  };

  /**
   * Add message to chat
   */
  const addMessage = (content, role) => {
    const messageDiv = document.createElement('div');
    messageDiv.className = `chat-message ${role}`;

    const avatar = document.createElement('div');
    avatar.className = 'chat-message-avatar';
    avatar.textContent = role === 'user' ? 'You' : 'AI';

    const contentDiv = document.createElement('div');
    contentDiv.className = 'chat-message-content';
    contentDiv.textContent = content;

    messageDiv.appendChild(avatar);
    messageDiv.appendChild(contentDiv);
    chatMessages.appendChild(messageDiv);

    // Auto-scroll to bottom
    chatMessages.scrollTop = chatMessages.scrollHeight;
  };

  /**
   * Add loading indicator
   */
  const addLoadingMessage = () => {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'chat-message loading assistant';
    messageDiv.id = 'loading-message';

    const avatar = document.createElement('div');
    avatar.className = 'chat-message-avatar';
    avatar.textContent = 'AI';

    const contentDiv = document.createElement('div');
    contentDiv.className = 'chat-message-content';
    contentDiv.innerHTML = '<div class="loading-dot"></div><div class="loading-dot"></div><div class="loading-dot"></div>';

    messageDiv.appendChild(avatar);
    messageDiv.appendChild(contentDiv);
    chatMessages.appendChild(messageDiv);

    chatMessages.scrollTop = chatMessages.scrollHeight;
  };

  /**
   * Remove loading indicator
   */
  const removeLoadingMessage = () => {
    const loadingMessage = document.getElementById('loading-message');
    if (loadingMessage) {
      loadingMessage.remove();
    }
  };

  /**
   * Send message to API
   */
  const sendMessage = async (event) => {
    event.preventDefault();

    const message = chatInput.value.trim();
    if (!message) return;

    // Prevent double sends
    if (isLoading) return;

    // Add user message
    addMessage(message, 'user');
    chatInput.value = '';

    // Show loading state
    isLoading = true;
    addLoadingMessage();

    try {
      const response = await fetch(API_ENDPOINT, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message }),
      });

      removeLoadingMessage();

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const errorMessage = errorData.error || `Error: ${response.status} ${response.statusText}`;
        addMessage(`Sorry, I encountered an error: ${errorMessage}`, 'assistant');
        isLoading = false;
        return;
      }

      const data = await response.json();
      const reply = data.reply || 'No response received';

      addMessage(reply, 'assistant');

      // Track conversation and offer lead capture after 4 exchanges
      messageCount++;
      if (messageCount >= 4 && !hasOfferedLeadCapture) {
        setTimeout(showLeadCapturePrompt, 1500);
      }
    } catch (error) {
      removeLoadingMessage();
      console.error('Chat API Error:', error);
      addMessage(
        'Sorry, I couldn\'t connect to the service. Please try again later.',
        'assistant'
      );
    } finally {
      isLoading = false;
      chatInput.focus();
    }
  };

  /**
   * Event Listeners
   */
  chatToggle.addEventListener('click', toggleChat);
  chatClose.addEventListener('click', toggleChat);
  chatForm.addEventListener('submit', sendMessage);

  // Drag event listeners - works on both avatar and header
  chatToggle.addEventListener('mousedown', startDrag);
  chatHeader.addEventListener('mousedown', startDrag);
  document.addEventListener('mousemove', (e) => {
    drag(e);
    resize(e);
  });
  document.addEventListener('mouseup', (e) => {
    stopDrag(e);
    stopResize();
  });

  // Resize handle event listeners
  const resizeHandles = document.querySelectorAll('.resize-handle');
  resizeHandles.forEach(handle => {
    const direction = handle.className.split(' ')[1].replace('resize-handle-', '');
    handle.addEventListener('mousedown', (e) => startResize(e, direction));
  });

  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && isOpen) {
      toggleChat();
    }
  });

  // Prevent form submission on Enter if still loading
  chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && isLoading) {
      e.preventDefault();
    }
  });

  // Handle window resize - only adjust height if it exceeds viewport
  window.addEventListener('resize', () => {
    const maxAllowedHeight = getMaxHeight();
    const computedHeight = chatWindow.getBoundingClientRect().height;

    if (computedHeight > maxAllowedHeight) {
      chatWindow.style.height = `${maxAllowedHeight}px`;
    }
  });

  // Initialize: Ensure chat window height fits viewport on page load
  const initMaxHeight = getMaxHeight();
  const initialHeight = chatWindow.getBoundingClientRect().height;
  if (initialHeight > initMaxHeight) {
    chatWindow.style.height = `${initMaxHeight}px`;
  }
});
