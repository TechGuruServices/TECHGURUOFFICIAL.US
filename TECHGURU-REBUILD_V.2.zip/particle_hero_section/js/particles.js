/*
 * Interactive particle system for the hero section.
 *
 * Particles drift randomly across the canvas and are repelled by the user's
 * cursor or touch input. The physics are simple: each particle has a
 * velocity vector that is perturbed by a repulsion force when it enters the
 * interaction radius. The result is a premium interactive experience that
 * feels responsive and alive without requiring external libraries.
 */

(() => {
  const canvas = document.getElementById('particle-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const particles = [];
  const NUM_PARTICLES = 140;

  const mouse = {
    x: null,
    y: null,
    radius: 120,
  };

  // Handle mouse and touch events
  function updateMousePosition(e) {
    const rect = canvas.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    mouse.x = clientX - rect.left;
    mouse.y = clientY - rect.top;
  }
  window.addEventListener('mousemove', updateMousePosition);
  window.addEventListener('touchmove', updateMousePosition, { passive: true });
  window.addEventListener('mouseleave', () => {
    mouse.x = null;
    mouse.y = null;
  });

  function resize() {
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
  }
  window.addEventListener('resize', () => {
    resize();
  });

  class Particle {
    constructor() {
      this.reset();
    }
    reset() {
      this.x = Math.random() * canvas.width;
      this.y = Math.random() * canvas.height;
      const angle = Math.random() * Math.PI * 2;
      const speed = 0.5 + Math.random() * 1.5;
      this.dx = Math.cos(angle) * speed;
      this.dy = Math.sin(angle) * speed;
      this.size = 2 + Math.random() * 2;
      // assign a slight hue shift for variety
      this.baseHue = Math.random() * 360;
    }
    update() {
      // apply repulsion force if mouse is present
      if (mouse.x !== null && mouse.y !== null) {
        const dx = this.x - mouse.x;
        const dy = this.y - mouse.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        if (distance < mouse.radius) {
          // normalized vector pointing away from cursor
          const forceDirectionX = dx / distance;
          const forceDirectionY = dy / distance;
          // repulsion strength scaled by proximity
          const force = (mouse.radius - distance) / mouse.radius;
          const repulsion = force * 2.5;
          this.dx += forceDirectionX * repulsion;
          this.dy += forceDirectionY * repulsion;
        }
      }
      // apply friction to gradually reduce velocity
      this.dx *= 0.98;
      this.dy *= 0.98;
      // update position
      this.x += this.dx;
      this.y += this.dy;
      // wrap around edges
      if (this.x > canvas.width + this.size) this.x = -this.size;
      else if (this.x < -this.size) this.x = canvas.width + this.size;
      if (this.y > canvas.height + this.size) this.y = -this.size;
      else if (this.y < -this.size) this.y = canvas.height + this.size;
    }
    draw() {
      ctx.beginPath();
      const hue = (this.baseHue + performance.now() * 0.02) % 360;
      ctx.fillStyle = `hsla(${hue}, 80%, 60%, 0.8)`;
      ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function initParticles() {
    particles.length = 0;
    for (let i = 0; i < NUM_PARTICLES; i++) {
      particles.push(new Particle());
    }
  }

  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach((p) => {
      p.update();
      p.draw();
    });
    requestAnimationFrame(animate);
  }

  // Initialize
  resize();
  initParticles();
  animate();
})();