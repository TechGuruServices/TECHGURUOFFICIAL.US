/*
 * Premium TECHGURU Landing Page JavaScript
 *
 * Handles form submissions for the newsletter sign‑up and contact forms.
 * Provides simple feedback messages upon success or failure.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Newsletter subscription
  const subscribeForm = document.getElementById('subscribe-form');
  if (subscribeForm) {
    subscribeForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const emailInput = document.getElementById('subscribe-email');
      const email = emailInput.value.trim();
      if (!email) {
        alert('Please enter a valid email address.');
        return;
      }
      try {
        const res = await fetch('/api/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email })
        });
        if (!res.ok) throw new Error('Network response was not ok');
        alert('Thank you for subscribing! Please check your inbox for confirmation.');
        subscribeForm.reset();
      } catch (err) {
        console.error(err);
        alert('There was an error subscribing. Please try again later.');
      }
    });
  }

  // Contact form
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(contactForm);
      const payload = Object.fromEntries(formData.entries());
      try {
        const res = await fetch('/api/contact', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        if (!res.ok) throw new Error('Network response was not ok');
        alert('Thank you for reaching out! We will respond soon.');
        contactForm.reset();
      }       catch (err) {
        console.error(err);
        alert('There was an error sending your message. Please try again later.');
      }
    });
  }

  // Navbar hide/show on scroll
  const navbar = document.querySelector('.navbar');
  let lastScrollY = window.scrollY;
  let ticking = false;

  const handleScroll = () => {
    const currentScrollY = window.scrollY;

    if (currentScrollY > lastScrollY && currentScrollY > 80) {
      // Scrolling down & past threshold - hide navbar
      navbar.classList.add('navbar-hidden');
    } else {
      // Scrolling up - show navbar
      navbar.classList.remove('navbar-hidden');
    }

    lastScrollY = currentScrollY;
    ticking = false;
  };

  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(handleScroll);
      ticking = true;
    }
  });
});
