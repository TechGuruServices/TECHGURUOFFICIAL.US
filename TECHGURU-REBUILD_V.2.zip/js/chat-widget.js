/*
 * Chat Widget JavaScript
 *
 * Handles chat widget toggle, message sending, and API integration
 * Connects to the TechGuru Workers API (/api/chat endpoint)
 */

document.addEventListener('DOMContentLoaded', () => {
  const chatToggle = document.getElementById('chat-toggle');
  const chatWindow = document.getElementById('chat-window');
  const chatClose = document.getElementById('chat-close');
  const chatForm = document.getElementById('chat-form');
  const chatInput = document.getElementById('chat-input');
  const chatMessages = document.getElementById('chat-messages');
  const chatHeader = document.querySelector('.chat-header');
  const chatContainer = document.querySelector('.chat-widget-container');

  const API_ENDPOINT = '/api/chat';
  let isOpen = false;
  let isLoading = false;

  // Dragging state
  let isDragging = false;
  let dragOffsetX = 0;
  let dragOffsetY = 0;
  let dragStartX = 0;
  let dragStartY = 0;
  let hasMoved = false;

  // Resizing state
  let isResizing = false;
  let resizeDirection = null;
  let resizeStartX = 0;
  let resizeStartY = 0;
  let resizeStartWidth = 0;
  let resizeStartHeight = 0;
  let resizeStartLeft = 0;
  let resizeStartTop = 0;
  let resizeStartRight = 0;
  let resizeStartBottom = 0;

  // Min and max dimensions
  const MIN_WIDTH = 280;
  const MIN_HEIGHT = 400;
  const MAX_WIDTH = 600;

  // Calculate max height dynamically to prevent overflow (viewport height - avatar height - padding)
  const getMaxHeight = () => Math.min(800, window.innerHeight - 140);

  /**
   * Toggle chat window open/close
   */
  const toggleChat = (e) => {
    // Don't toggle if user was dragging
    if (hasMoved) {
      hasMoved = false;
      return;
    }

    isOpen = !isOpen;

    if (isOpen) {
      chatWindow.classList.add('open');
      chatToggle.classList.add('active');
      chatInput.focus();

      // Show welcome message on first open
      if (chatMessages.children.length === 0) {
        addWelcomeMessage();
      }
    } else {
      chatWindow.classList.remove('open');
      chatToggle.classList.remove('active');
    }
  };

  /**
   * Drag functionality for chat widget container
   */
  const startDrag = (e) => {
    if (e.target.closest('.chat-close') || e.target.closest('#chat-input') || e.target.closest('.chat-send') || e.target.classList.contains('resize-handle')) {
      return; // Don't drag when clicking close button, input, or resize handles
    }

    isDragging = true;
    hasMoved = false;
    dragStartX = e.clientX;
    dragStartY = e.clientY;

    const rect = chatContainer.getBoundingClientRect();
    dragOffsetX = e.clientX - rect.left;
    dragOffsetY = e.clientY - rect.top;

    if (chatHeader.style) chatHeader.style.cursor = 'grabbing';
    e.preventDefault();
  };

  const drag = (e) => {
    if (!isDragging) return;

    const moveDistance = Math.abs(e.clientX - dragStartX) + Math.abs(e.clientY - dragStartY);
    if (moveDistance > 5) {
      hasMoved = true;
    }

    e.preventDefault();

    const newLeft = e.clientX - dragOffsetX;
    const newTop = e.clientY - dragOffsetY;

    // Update container position
    chatContainer.style.position = 'fixed';
    chatContainer.style.left = `${newLeft}px`;
    chatContainer.style.top = `${newTop}px`;
    chatContainer.style.right = 'auto';
    chatContainer.style.bottom = 'auto';
  };

  const stopDrag = (e) => {
    if (isDragging) {
      isDragging = false;
      if (chatHeader.style) chatHeader.style.cursor = 'move';
    }
  };

  /**
   * Resize functionality for chat window
   */
  const startResize = (e, direction) => {
    isResizing = true;
    resizeDirection = direction;
    resizeStartX = e.clientX;
    resizeStartY = e.clientY;

    const rect = chatWindow.getBoundingClientRect();
    const currentStyle = window.getComputedStyle(chatWindow);
    const containerStyle = window.getComputedStyle(chatContainer);

    resizeStartWidth = rect.width;
    resizeStartHeight = rect.height;

    // Check if using fixed positioning (after drag) or absolute (initial)
    const usingFixedPosition = containerStyle.position === 'fixed' && containerStyle.left !== 'auto';

    if (usingFixedPosition) {
      // Container has been dragged and uses left/top positioning
      resizeStartLeft = parseInt(containerStyle.left) || 0;
      resizeStartTop = parseInt(containerStyle.top) || 0;
    } else {
      // Using initial bottom/right positioning
      resizeStartRight = parseInt(currentStyle.right) || 0;
      resizeStartBottom = parseInt(currentStyle.bottom) || 120;
    }

    e.preventDefault();
    e.stopPropagation();
  };

  const resize = (e) => {
    if (!isResizing) return;

    e.preventDefault();

    const deltaX = e.clientX - resizeStartX;
    const deltaY = e.clientY - resizeStartY;

    let newWidth = resizeStartWidth;
    let newHeight = resizeStartHeight;

    const containerStyle = window.getComputedStyle(chatContainer);
    const usingFixedPosition = containerStyle.position === 'fixed' && containerStyle.left !== 'auto';

    // Calculate dynamic max height based on current position
    let maxAllowedHeight = getMaxHeight();

    if (usingFixedPosition) {
      // If using fixed positioning, calculate max height based on current top position
      const currentTop = parseInt(containerStyle.top) || 0;
      maxAllowedHeight = Math.min(maxAllowedHeight, window.innerHeight - currentTop - 20); // 20px bottom padding
    }

    // Handle horizontal resizing
    if (resizeDirection.includes('e')) {
      newWidth = resizeStartWidth + deltaX;
    } else if (resizeDirection.includes('w')) {
      newWidth = resizeStartWidth - deltaX;

      // Adjust position when resizing from west edge
      if (usingFixedPosition) {
        const widthDiff = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, newWidth)) - resizeStartWidth;
        const newLeft = resizeStartLeft - widthDiff;
        // Prevent moving off left edge
        chatContainer.style.left = `${Math.max(0, newLeft)}px`;
      } else {
        const widthDiff = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, newWidth)) - resizeStartWidth;
        chatWindow.style.right = `${resizeStartRight - widthDiff}px`;
      }
    }

    // Handle vertical resizing
    if (resizeDirection.includes('s')) {
      newHeight = resizeStartHeight + deltaY;
    } else if (resizeDirection.includes('n')) {
      newHeight = resizeStartHeight - deltaY;

      // Adjust position when resizing from north edge
      if (usingFixedPosition) {
        const heightDiff = Math.max(MIN_HEIGHT, Math.min(maxAllowedHeight, newHeight)) - resizeStartHeight;
        const newTop = resizeStartTop - heightDiff;
        // Prevent moving off top edge
        chatContainer.style.top = `${Math.max(0, newTop)}px`;
      } else {
        const heightDiff = Math.max(MIN_HEIGHT, Math.min(maxAllowedHeight, newHeight)) - resizeStartHeight;
        chatWindow.style.bottom = `${resizeStartBottom - heightDiff}px`;
      }
    }

    // Constrain to min/max dimensions (with dynamic viewport constraint for height)
    const constrainedWidth = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, newWidth));
    const constrainedHeight = Math.max(MIN_HEIGHT, Math.min(maxAllowedHeight, newHeight));

    chatWindow.style.width = `${constrainedWidth}px`;
    chatWindow.style.height = `${constrainedHeight}px`;
  };  const stopResize = () => {
    if (isResizing) {
      isResizing = false;
      resizeDirection = null;
    }
  };  /**
   * Add welcome message
   */
  const addWelcomeMessage = () => {
    addMessage(
      'Hi! 👋 I\'m the TechGuru AI Assistant. Ask me anything about our services, pricing, or how we can help your business. What brings you here today?',
      'assistant'
    );
  };

  /**
   * Add message to chat
   */
  const addMessage = (content, role) => {
    const messageDiv = document.createElement('div');
    messageDiv.className = `chat-message ${role}`;

    const avatar = document.createElement('div');
    avatar.className = 'chat-message-avatar';
    avatar.textContent = role === 'user' ? 'You' : 'AI';

    const contentDiv = document.createElement('div');
    contentDiv.className = 'chat-message-content';
    contentDiv.textContent = content;

    messageDiv.appendChild(avatar);
    messageDiv.appendChild(contentDiv);
    chatMessages.appendChild(messageDiv);

    // Auto-scroll to bottom
    chatMessages.scrollTop = chatMessages.scrollHeight;
  };

  /**
   * Add loading indicator
   */
  const addLoadingMessage = () => {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'chat-message loading assistant';
    messageDiv.id = 'loading-message';

    const avatar = document.createElement('div');
    avatar.className = 'chat-message-avatar';
    avatar.textContent = 'AI';

    const contentDiv = document.createElement('div');
    contentDiv.className = 'chat-message-content';
    contentDiv.innerHTML = '<div class="loading-dot"></div><div class="loading-dot"></div><div class="loading-dot"></div>';

    messageDiv.appendChild(avatar);
    messageDiv.appendChild(contentDiv);
    chatMessages.appendChild(messageDiv);

    chatMessages.scrollTop = chatMessages.scrollHeight;
  };

  /**
   * Remove loading indicator
   */
  const removeLoadingMessage = () => {
    const loadingMessage = document.getElementById('loading-message');
    if (loadingMessage) {
      loadingMessage.remove();
    }
  };

  /**
   * Send message to API
   */
  const sendMessage = async (event) => {
    event.preventDefault();

    const message = chatInput.value.trim();
    if (!message) return;

    // Prevent double sends
    if (isLoading) return;

    // Add user message
    addMessage(message, 'user');
    chatInput.value = '';

    // Show loading state
    isLoading = true;
    addLoadingMessage();

    try {
      const response = await fetch(API_ENDPOINT, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message }),
      });

      removeLoadingMessage();

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const errorMessage = errorData.error || `Error: ${response.status} ${response.statusText}`;
        addMessage(`Sorry, I encountered an error: ${errorMessage}`, 'assistant');
        isLoading = false;
        return;
      }

      const data = await response.json();
      const reply = data.reply || 'No response received';

      addMessage(reply, 'assistant');
    } catch (error) {
      removeLoadingMessage();
      console.error('Chat API Error:', error);
      addMessage(
        'Sorry, I couldn\'t connect to the service. Please try again later.',
        'assistant'
      );
    } finally {
      isLoading = false;
      chatInput.focus();
    }
  };

  /**
   * Event Listeners
   */
  chatToggle.addEventListener('click', toggleChat);
  chatClose.addEventListener('click', toggleChat);
  chatForm.addEventListener('submit', sendMessage);

  // Drag event listeners - works on both avatar and header
  chatToggle.addEventListener('mousedown', startDrag);
  chatHeader.addEventListener('mousedown', startDrag);
  document.addEventListener('mousemove', (e) => {
    drag(e);
    resize(e);
  });
  document.addEventListener('mouseup', (e) => {
    stopDrag(e);
    stopResize();
  });

  // Resize handle event listeners
  const resizeHandles = document.querySelectorAll('.resize-handle');
  resizeHandles.forEach(handle => {
    const direction = handle.className.split(' ')[1].replace('resize-handle-', '');
    handle.addEventListener('mousedown', (e) => startResize(e, direction));
  });

  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && isOpen) {
      toggleChat();
    }
  });

  // Prevent form submission on Enter if still loading
  chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && isLoading) {
      e.preventDefault();
    }
  });

  // Handle window resize - only adjust height if it exceeds viewport
  window.addEventListener('resize', () => {
    const maxAllowedHeight = getMaxHeight();
    const computedHeight = chatWindow.getBoundingClientRect().height;

    if (computedHeight > maxAllowedHeight) {
      chatWindow.style.height = `${maxAllowedHeight}px`;
    }
  });

  // Initialize: Ensure chat window height fits viewport on page load
  const initMaxHeight = getMaxHeight();
  const initialHeight = chatWindow.getBoundingClientRect().height;
  if (initialHeight > initMaxHeight) {
    chatWindow.style.height = `${initMaxHeight}px`;
  }
});
